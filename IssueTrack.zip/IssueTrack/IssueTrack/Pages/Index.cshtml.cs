﻿using IssueTrack.Data;
using IssueTrack.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace IssueTrack.Pages
{
    public class IndexModel : PageModel
    {
        private readonly IssueDbContext _context;
        // declarationg IssueDbContext in the constructor ... this way it will be injected at run time by dependency injection container
        public IndexModel(IssueDbContext context) => _context = context;

        // a handle ..method executed in response to a HTTP request (like Get request)
        public async void OnGet()
        {
            Issues = await _context.Issues.Where(i => i.Completed == null)
                .OrderByDescending(i => i.Created)
                .ToListAsync();
        }

        public IEnumerable<Issue> Issues { get; set; } = Enumerable.Empty<Issue>();

      
    }
}