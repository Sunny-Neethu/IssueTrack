using IssueTrack.Data;
using IssueTrack.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IssueTrack.Pages.Issues
{
    public class NewModel : PageModel
    {
        private readonly IssueDbContext _context;

        // declare the constructor as we need to save data
        public NewModel(IssueDbContext context) => _context = context;

        // we submit data using Post method ..hence change OnGet to OnPost
        // we aren't returning void but action result
        public async Task<IActionResult> OnPost()
        {
            // the below is server side validation for form ... the ModelState is an object and it will say if the model is valid according to validation attru=ibutes we set on model
            // if !modelState return to Page for user to be redirected to home page
            if (!ModelState.IsValid) return Page();

            Issue.Created = DateTime.Now;
            await _context.Issues.AddAsync(Issue);
            await _context.SaveChangesAsync();

            return RedirectToPage("../Index");
        }

        // this will hold data submitted in the form
        [BindProperty]
        public Issue Issue { get; set; }
       
    }
}
